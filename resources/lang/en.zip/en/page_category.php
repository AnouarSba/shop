<?php

/**
 * page.php
 *
 * @copyright  2022 beikeshop.com - All Rights Reserved
 * @link       https://beikeshop.com
 * @author     TL <mengwb@guangda.work>
 * @created    2022-07-28 20:59:38
 * @modified   2022-07-28 20:59:38
 */
return [
    'index'        => 'News blog',
    'author'       => 'Author',
    'views'        => 'View number',
    'created_at'   => 'Release time',
    'text_summary' => 'Summary',
];
