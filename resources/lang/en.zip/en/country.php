<?php
/**
 * Lang.php
 *
 *
 * @created    2023-09-09 09:09:09
 * @modified   2023-12-12 07:28:50
 */

return [
    'AF'   => 'Africa',
    'AN'   => 'Antarctica',
    'AS'   => 'Asia',
    'EU'   => 'Europe',
    'NA'   => 'North America',
    'OA'   => 'Oceania',
    'SA'   => 'South America',
    'null' => 'unknown',
];
