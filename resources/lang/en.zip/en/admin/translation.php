<?php
/**
 * Lang.php
 *
 *
 * @created    2023-09-09 09:09:09
 * @modified   2023-09-15 08:00:03
 */

return [
    'class_not_found'  => 'Class :translator_name could not be found',
    'empty_translator' => 'No translation tools are enabled, please open Plugins - Translation Tools - Select Translation Tool configuration and enable',
];
