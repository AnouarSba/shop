<?php
/**
 * Lang.php
 *
 *
 * @created    2023-09-09 09:09:09
 * @modified   2023-12-12 07:12:50
 */

return [
    'approved'       => 'Approved',
    'customer_group' => 'Group',
    'email'          => 'Email',
    'from'           => 'From',
    'name'           => 'Name',
    'pending'        => 'Pending',
    'rejected'       => 'Rejected',
];
