<?php
/**
 * Lang.php
 *
 *
 * @created    2023-09-09 09:09:09
 * @modified   2023-12-12 07:18:50
 */

return [
    'ct' => 'karat',
    'g'  => 'g',
    'kg' => 'kilogram',
    'lb' => 'pounds',
    'oz' => 'ounce',
];
